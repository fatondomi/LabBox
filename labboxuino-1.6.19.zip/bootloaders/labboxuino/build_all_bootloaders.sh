#!/bin/bash -ex

BOARD_ID=labboxuino NAME=samd21_sam_ba make clean all

echo Done building bootloaders!

